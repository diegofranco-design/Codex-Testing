
  # Trust OS - Library

  This is a code bundle for Trust OS - Library. The original project is available at https://www.figma.com/design/sXYpvwM9MlIhkgD9gGYW4l/Trust-OS---Library.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  
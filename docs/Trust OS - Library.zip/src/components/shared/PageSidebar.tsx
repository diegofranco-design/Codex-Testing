import React from "react";
import { BookOpen, Layers } from "lucide-react";
import { cn } from "../ui/utils";
import { Badge } from "../ui/badge";

export interface SidebarSection {
  id: string;
  label: string;
}

export interface Pillar {
  label: string;
  color: "blue" | "green" | "amber" | "slate" | "purple";
}

interface PageSidebarProps {
  sections: SidebarSection[];
  activeSection: string;
  pillars?: Pillar[];
  figmaAssetUrl?: string;
  onSectionClick?: (id: string) => void;
}

export function PageSidebar({ 
  sections, 
  activeSection, 
  pillars = [], 
  figmaAssetUrl,
  onSectionClick 
}: PageSidebarProps) {
  
  const handleScroll = (e: React.MouseEvent, id: string) => {
    e.preventDefault();
    if (onSectionClick) {
      onSectionClick(id);
    } else {
      const el = document.getElementById(id);
      if (el) {
        el.scrollIntoView({ behavior: "smooth" });
      }
    }
  };

  const getBadgeStyles = (color: string) => {
    switch (color) {
        case "blue": return "bg-blue-100 text-blue-800 border-blue-200 hover:bg-blue-200 hover:text-blue-900";
        case "green": return "bg-green-100 text-green-800 border-green-200 hover:bg-green-200 hover:text-green-900";
        case "amber": return "bg-amber-100 text-amber-800 border-amber-200 hover:bg-amber-200 hover:text-amber-900";
        case "purple": return "bg-purple-100 text-purple-800 border-purple-200 hover:bg-purple-200 hover:text-purple-900";
        default: return "bg-slate-100 text-slate-800 border-slate-200 hover:bg-slate-200 hover:text-slate-900";
    }
  };

  return (
    <div className="sticky top-24 space-y-8">
      {/* On this page */}
      <div>
        <h4 className="font-semibold text-foreground mb-4 flex items-center gap-2">
          <BookOpen className="h-4 w-4 text-muted-foreground" />
          On this page
        </h4>
        <nav className="space-y-1 border-l-2 border-border">
          {sections.map((link) => {
            const isActive = activeSection === link.id;
            return (
              <a 
                key={link.id}
                href={`#${link.id}`}
                onClick={(e) => handleScroll(e, link.id)}
                className={cn(
                  "block pl-4 py-1.5 text-sm border-l-2 transition-all -ml-[2px]",
                  isActive 
                    ? "border-primary text-primary font-medium" 
                    : "border-transparent text-muted-foreground hover:text-foreground hover:border-muted-foreground/30"
                )}
              >
                {link.label}
              </a>
            );
          })}
        </nav>
      </div>

      {/* Pillars */}
      {pillars.length > 0 && (
        <div>
          <h4 className="font-semibold text-foreground mb-3 flex items-center gap-2">
            <Layers className="h-4 w-4 text-muted-foreground" />
            Trust Pillars
          </h4>
          <div className="flex flex-wrap gap-2">
            {pillars.map((pillar, i) => (
              <Badge 
                key={i} 
                variant="outline" 
                className={cn("border font-medium", getBadgeStyles(pillar.color))}
              >
                {pillar.label}
              </Badge>
            ))}
          </div>
        </div>
      )}

      {/* Figma Assets Button */}
      {figmaAssetUrl && (
        <div>
          <a
            href={figmaAssetUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-3 px-4 py-3 bg-card border border-border rounded-lg hover:border-primary/50 hover:shadow-md transition-all duration-200 group"
          >
            {/* Figma Logo SVG */}
            <svg
              className="h-5 w-5 shrink-0"
              viewBox="0 0 38 57"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M19 28.5C19 23.2533 23.2533 19 28.5 19C33.7467 19 38 23.2533 38 28.5C38 33.7467 33.7467 38 28.5 38C23.2533 38 19 33.7467 19 28.5Z"
                fill="#1ABCFE"
              />
              <path
                d="M0 47.5C0 42.2533 4.25329 38 9.5 38H19V47.5C19 52.7467 14.7467 57 9.5 57C4.25329 57 0 52.7467 0 47.5Z"
                fill="#0ACF83"
              />
              <path
                d="M19 0V19H28.5C33.7467 19 38 14.7467 38 9.5C38 4.25329 33.7467 0 28.5 0H19Z"
                fill="#FF7262"
              />
              <path
                d="M0 9.5C0 14.7467 4.25329 19 9.5 19H19V0H9.5C4.25329 0 0 4.25329 0 9.5Z"
                fill="#F24E1E"
              />
              <path
                d="M0 28.5C0 33.7467 4.25329 38 9.5 38H19V19H9.5C4.25329 19 0 23.2533 0 28.5Z"
                fill="#A259FF"
              />
            </svg>
            
            <div className="flex-1 min-w-0">
              <div className="text-sm font-semibold text-foreground group-hover:text-primary transition-colors">
                Visit Figma Assets
              </div>
            </div>
            
            {/* External link icon */}
            <svg
              className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors shrink-0"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"
              />
            </svg>
          </a>
        </div>
      )}
    </div>
  );
}